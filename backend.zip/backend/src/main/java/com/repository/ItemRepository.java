package com.lostfound.backend.repository;

import com.lostfound.backend.entity.Item;
import com.lostfound.backend.entity.ItemType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ItemRepository extends JpaRepository<Item, Long> {

    List<Item> findByType(ItemType type);
}