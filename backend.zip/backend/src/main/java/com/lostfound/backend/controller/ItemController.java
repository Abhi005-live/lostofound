package com.lostfound.backend.controller;

import com.lostfound.backend.dto.ItemRequest;
import com.lostfound.backend.dto.ItemResponse;
import com.lostfound.backend.service.ItemService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/items")
@RequiredArgsConstructor
@CrossOrigin("*")
public class ItemController {

    private final ItemService itemService;

    @PostMapping
    public ItemResponse createItem(@Valid @RequestBody ItemRequest request) {
        return itemService.createItem(request);
    }

    @GetMapping
    public List<ItemResponse> getAllItems() {
        return itemService.getAllItems();
    }

    @GetMapping("/type/{type}")
    public List<ItemResponse> getByType(@PathVariable String type) {
        return itemService.getItemsByType(type);
    }
}