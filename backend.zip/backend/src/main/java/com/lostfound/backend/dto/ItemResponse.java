package com.lostfound.backend.dto;

import com.lostfound.backend.entity.ItemStatus;
import com.lostfound.backend.entity.ItemType;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class ItemResponse {

    private Long id;
    private String title;
    private String description;
    private String category;
    private String location;
    private String imageUrl;
    private ItemType type;
    private ItemStatus status;
    private LocalDateTime createdAt;
}