package com.lostfound.backend.dto;

import com.lostfound.backend.entity.ItemType;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ItemRequest {

    @NotBlank
    private String title;

    private String description;

    @NotBlank
    private String category;

    @NotBlank
    private String location;

    private String imageUrl;

    private ItemType type;
}