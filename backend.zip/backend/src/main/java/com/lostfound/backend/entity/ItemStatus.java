package com.lostfound.backend.entity;

public enum ItemStatus {
    OPEN,
    CLAIMED,
    RETURNED
}