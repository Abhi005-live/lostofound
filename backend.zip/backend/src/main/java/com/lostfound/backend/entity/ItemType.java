package com.lostfound.backend.entity;

public enum ItemType {
    LOST,
    FOUND
}