package com.lostfound.backend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Column(length = 1000)
    private String description;

    private String category;

    private String location;

    private String imageUrl;

    @Enumerated(EnumType.STRING)
    private ItemType type; // LOST or FOUND

    @Enumerated(EnumType.STRING)
    private ItemStatus status = ItemStatus.OPEN;

    private LocalDateTime createdAt = LocalDateTime.now();
}