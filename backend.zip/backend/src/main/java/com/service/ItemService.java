package com.lostfound.backend.service;

import java.util.List;

import com.lostfound.backend.dto.ItemRequest;
import com.lostfound.backend.dto.ItemResponse;

public interface ItemService {

    ItemResponse createItem(ItemRequest request);

    List<ItemResponse> getAllItems();

    List<ItemResponse> getItemsByType(String type);
}