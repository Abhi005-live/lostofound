package com.lostfound.backend.service.impl;

import com.lostfound.backend.dto.ItemRequest;
import com.lostfound.backend.dto.ItemResponse;
import com.lostfound.backend.entity.Item;
import com.lostfound.backend.entity.ItemType;
import com.lostfound.backend.repository.ItemRepository;
import com.lostfound.backend.service.ItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ItemServiceImpl implements ItemService {

    private final ItemRepository itemRepository;

    @Override
    public ItemResponse createItem(ItemRequest request) {

        Item item = Item.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .category(request.getCategory())
                .location(request.getLocation())
                .imageUrl(request.getImageUrl())
                .type(request.getType())
                .build();

        Item saved = itemRepository.save(item);

        return mapToResponse(saved);
    }

    @Override
    public List<ItemResponse> getAllItems() {
        return itemRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public List<ItemResponse> getItemsByType(String type) {

        ItemType itemType = ItemType.valueOf(type.toUpperCase());

        return itemRepository.findByType(itemType)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    private ItemResponse mapToResponse(Item item) {
        return ItemResponse.builder()
                .id(item.getId())
                .title(item.getTitle())
                .description(item.getDescription())
                .category(item.getCategory())
                .location(item.getLocation())
                .imageUrl(item.getImageUrl())
                .type(item.getType())
                .status(item.getStatus())
                .createdAt(item.getCreatedAt())
                .build();
    }
}